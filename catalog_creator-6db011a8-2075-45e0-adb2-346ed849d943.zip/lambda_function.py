import boto3
import time
import json

def lambda_handler(event, context):
    database = event.get('database', 'masked_data_db')
    table = event.get('tablename')
    sourcedate = event.get('sourcedate')
    batchid = event.get('batchid')
    output_bucket = event.get('athena_output_bucket', 'athena-query-results-dacef568-1208-43c1-9a4e-gokul')  # Replace or pass in event

    if not table or not sourcedate or not batchid:
        return {
            'statusCode': 400,
            'body': json.dumps('Missing required parameter: tablename, sourcedate, or batchid')
        }

    athena = boto3.client('athena')
    s3_partition_path = f"s3://masked-data-bucket-gokul/{table}/sourcedate={sourcedate}/batchid={batchid}/"
    output_location = f"s3://{output_bucket}/msck-repair-output/"

    print(f"Registering partition at: {s3_partition_path}")
    print(f"Athena output location: {output_location}")

    query = f"""
    ALTER TABLE {database}.{table}
    ADD IF NOT EXISTS
    PARTITION (sourcedate='{sourcedate}', batchid='{batchid}')
    LOCATION '{s3_partition_path}'
    """

    print(f"Running Athena query:\n{query}")

    try:
        response = athena.start_query_execution(
            QueryString=query,
            QueryExecutionContext={'Database': database},
            ResultConfiguration={'OutputLocation': output_location}
        )

        query_execution_id = response['QueryExecutionId']
        print(f"Athena query started. Execution ID: {query_execution_id}")

        # Poll until query finishes
        while True:
            result = athena.get_query_execution(QueryExecutionId=query_execution_id)
            state = result['QueryExecution']['Status']['State']
            print(f"Current query state: {state}")
            if state in ['SUCCEEDED', 'FAILED', 'CANCELLED']:
                break
            time.sleep(3)

        if state != 'SUCCEEDED':
            reason = result['QueryExecution']['Status'].get('StateChangeReason', 'Unknown reason')
            raise Exception(f"Athena query failed with reason: {reason}")

        return {
            'statusCode': 200,
            'body': json.dumps(f"Partition added successfully to {database}.{table}")
        }

    except Exception as e:
        print(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps(f"Error running partition registration query: {str(e)}")
        }

