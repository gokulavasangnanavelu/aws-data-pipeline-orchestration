import json
import boto3

def lambda_handler(event, context):
    # TODO implement
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }


### Below code utility to write the data in DDB table:
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('ddb-table-details')  # Replace with your actual table name

# Table name for partition key
# tablename = "ecommerce"
tablename = "ecommerce_orders"

# List of column definitions to write
# columns = [
#     {"columnname": "StudentID", "datatype": "int", "encryption": True},
#     {"columnname": "Name", "datatype": "str", "encryption": False},
#     {"columnname": "DOB", "datatype": "str", "encryption": False},
#     {"columnname": "Email", "datatype": "str", "encryption": False},
#     {"columnname": "Phone", "datatype": "int", "encryption": False},
#     {"columnname": "Major", "datatype": "str", "encryption": True},
#     {"columnname": "GPA", "datatype": "float", "encryption": False},
# ]

columns = [
    {"columnname": "Category", "datatype": "int", "encryption": False},
    {"columnname": "Discount", "datatype": "str", "encryption": False},
    {"columnname": "Final_Price", "datatype": "str", "encryption": False},
    {"columnname": "Price", "datatype": "str", "encryption": False},
    {"columnname": "Product_ID", "datatype": "int", "encryption": False},
    {"columnname": "Purchase_Date", "datatype": "str", "encryption": False},
    {"columnname": "user_id", "datatype": "float", "encryption": True},
    {"columnname": "Payment_Method", "datatype": "float", "encryption": True}
]

# columns = [
#     {"columnname": "PatientID", "datatype": "str", "encryption": True},
#     {"columnname": "Name", "datatype": "str", "encryption": False},
#     {"columnname": "Age", "datatype": "str", "encryption": False},
#     {"columnname": "Gender", "datatype": "str", "encryption": False},
#     {"columnname": "Diagnosis", "datatype": "int", "encryption": False},
#     {"columnname": "SSN", "datatype": "str", "encryption": True},
#     {"columnname": "Phone", "datatype": "int", "encryption": False}
# ]


def lambda_handler(event, context):
    for col in columns:
        item = {
            "tablename": tablename,
            "columnname": col["columnname"],
            "datatype": col["datatype"],
            "encryption": col["encryption"]
        }
        try:
            table.put_item(Item=item)
            print(f"Inserted: {item}")
        except Exception as e:
            print(f"Error inserting {item['columnname']}: {str(e)}")

    return {
        "statusCode": 200,
        "body": "All items written to DynamoDB."
    }