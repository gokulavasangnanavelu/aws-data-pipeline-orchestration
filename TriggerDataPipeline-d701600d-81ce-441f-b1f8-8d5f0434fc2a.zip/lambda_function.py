import boto3
import os
import json
import datetime
import uuid

step_fn = boto3.client('stepfunctions')

def lambda_handler(event, context):
    # Extract bucket and object key from S3 event
    print(f"this is my event data: {event}")

    record = event['Records'][0]
    bucket = record['s3']['bucket']['name']
    key = record['s3']['object']['key']

    print("Received S3 key:", key)

    # Extract filename
    filename = os.path.basename(key)
    base_name = os.path.splitext(filename)[0]  # 'ecommerce_orders'

    # Use the first part as tablename, rest is optional
    parts = base_name.split('_')

    if len(parts) < 1:
        raise ValueError(f"Filename is not valid. Got: {filename}")

    tablename = parts[0]  # Required
    sourcedate = datetime.datetime.utcnow().strftime('%Y-%m-%d')  # Use today's date
    batchid = str(uuid.uuid4())[:8]  # Use a short UUID as batchid

    input_payload = {
        "tablename": tablename,
        "s3_input": f"s3://{bucket}/{key}",
        "sourcedate": sourcedate,
        "batchid": batchid
    }

    print("Triggering Step Function with input:", input_payload)

    response = step_fn.start_execution(
        stateMachineArn=os.environ['STEP_FUNCTION_ARN'],
        input=json.dumps(input_payload)
    )

    return {
        'statusCode': 200,
        'body': f"Step Function triggered: {response['executionArn']}"
    }

